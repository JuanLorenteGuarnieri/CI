**Execution**:

  The program can be executed in the same way as the demo you provided. To modify the type of aperture or other parameters, you can change those in the first lines of the code. For the rest of the practice, only the parameters for the other programs have been changed, so we do not submit it.this Toolbox installed.

**Authors**:  

    Juan Lorente Guarnieri 816020

    Hugo Mateo Trejo 816678